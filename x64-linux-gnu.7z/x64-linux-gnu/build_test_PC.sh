#! /bin/bash

echo "WARNING:Please must run this script in it's directory."
echo "Compile test app ..."
make

echo "Build the test environment for Upload and download"

echo "install the ftp put command ..."
sudo apt-get install ncftp

echo "install 7z compress command ..."
sudo apt-get install p7zip-full

echo "make some test folders ..."
cd obj
mkdir txn1
mkdir txn2
mkdir logDir
mkdir lnkDir
mkdir logBakDir
mkdir tmp
cd ..

echo "Copy certificate file ..."
cp cert_afc.pem ./obj/

echo "Copy log test file ..."
cp 000154-20140619171331.log ./obj/logDir/

echo "Copy transaction test file ..."
cp BVTTXN-LAAAA02-B101010-M101010-00603-20131118-144537.rec ./obj/txn1/
cp BVTTXN-LAAAA02-B101010-M101010-00603-20131118-1445377.rec ./obj/txn2/

echo "Create transaction link file ..."
ln -s ./obj/txn1/BVTTXN-LAAAA02-B101010-M101010-00603-20131118-144537.rec ./obj/lnkDir/BVTTXN-LAAAA02-B101010-M101010-00603-20131118-144537.rec
ln -s ./obj/txn2/BVTTXN-LAAAA02-B101010-M101010-00603-20131118-1445377.rec ./obj/lnkDir/BVTTXN-LAAAA02-B101010-M101010-00603-20131118-1445377.rec

echo "Done"
